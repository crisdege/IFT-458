
// function greetTheStudent(studentName) { // parameter
//     return `Hello there ${studentName}`;
// }

// fat arrow function

const greetTheStudent =  (studentName) => `Hello there ${studentName}`;

const fullName = (firstname, middleName, lastName) => `${lastName}, ${middleName}, ${firstname}`

// const student = 'Mary Jane';
// const greet = greetTheStudent(student); // argument
// console.log(greet)

const titleName = fullName('Mary', 'R', 'Jane')
console.log(titleName)

// console.log(message + ' ' + studentName)
// console.log(message + ' ' + studentName2)
